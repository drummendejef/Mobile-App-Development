package be.verborgh.persoon;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link be.verborgh.persoon.EditPersonFragment.SavePersonListener} interface
 * to handle interaction events.
 * Use the {@link EditPersonFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EditPersonFragment extends Fragment {

    private static final String ARG_EMAIL = "be.verborgh.persoon.EMAIL";
    private static final String ARG_NAME = "be.verborgh.persoon.NAME";

    private String mName;
    private String mEmail;

    private SavePersonListener mListener;
    private EditText mEtEmail;
    private EditText mEtName;


    public static EditPersonFragment newInstance(String name, String email) {
        Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        args.putString(ARG_EMAIL, email);

        EditPersonFragment fragment = new EditPersonFragment();
        fragment.setArguments(args);

        return fragment;
    }

    public EditPersonFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mName = getArguments().getString(ARG_EMAIL);
            mEmail = getArguments().getString(ARG_NAME);
        }

        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_edit_person, container, false);

        mEtName = (EditText)v.findViewById(R.id.etName);
        mEtName.setText(mName);

        mEtEmail = (EditText)v.findViewById(R.id.etEmail);
        mEtEmail.setText(mEmail);

        return v;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_edit_person, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.mni_save_person) {
            String name = mEtName.getText().toString();
            String email  = mEtEmail.getText().toString();

            if(mListener != null) {
                mListener.onSavePerson(name, email);
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mListener = (SavePersonListener) activity;

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface SavePersonListener {
        public void onSavePerson(String name, String email);
    }

}
